"""
Document Mapper.

Convierte documentos enriquecidos del pipeline RAG al modelo
VectorDocument utilizado por el Vector Store.
"""

from uuid import uuid4

from langchain_core.documents import Document

from .types import VectorDocument


class DocumentMapper:
    """
    Convierte documentos LangChain a VectorDocument.
    """

    def map_documents(
        self,
        documents: list[Document],
    ) -> list[VectorDocument]:
        """
        Convierte documentos enriquecidos a VectorDocument.
        """

        vector_documents: list[VectorDocument] = []

        for document in documents:

            embedding = document.metadata.get("embedding")

            if embedding is None:
                raise ValueError(
                    "El documento no contiene embedding."
                )

            metadata = dict(document.metadata)

            metadata.pop("embedding", None)

            vector_documents.append(
                VectorDocument(
                    id=str(uuid4()),
                    page_content=document.page_content,
                    metadata=metadata,
                    embedding=embedding,
                )
            )

        return vector_documents