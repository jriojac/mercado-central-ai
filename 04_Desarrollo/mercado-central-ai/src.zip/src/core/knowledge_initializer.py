"""
=========================================================
Knowledge Initializer.

Responsable de construir la Base Vectorial del proyecto.

Pipeline:

PDF
    ↓
Document Loader
    ↓
Text Splitter
    ↓
Metadata Manager
    ↓
Embeddings
    ↓
Document Mapper
    ↓
Vector Store

Sprint 14 - Hito 12
=========================================================
"""

from src.knowledge.loader import DocumentLoader

from src.knowledge.text_splitter import TextSplitter

from src.knowledge.metadata import MetadataManager

from src.knowledge.embeddings import Embeddings

from src.knowledge.document_mapper import DocumentMapper

from src.knowledge.vector_store import VectorStore

from src.knowledge.providers.chroma_provider import ChromaProvider


class KnowledgeInitializer:
    """
    Inicializa completamente la Base Vectorial.
    """

    def __init__(self) -> None:
        """
        Inicializa todos los componentes del pipeline.
        """

        self._loader = DocumentLoader()

        self._splitter = TextSplitter()

        self._metadata = MetadataManager()

        self._embeddings = Embeddings()

        self._mapper = DocumentMapper()

        self._provider = ChromaProvider()

        self._vector_store = VectorStore(
            self._provider
        )