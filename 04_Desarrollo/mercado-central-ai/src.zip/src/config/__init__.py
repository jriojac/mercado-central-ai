"""
Paquete de configuración.
"""